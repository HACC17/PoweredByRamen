# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# Create your views here.
from django.shortcuts import render
#from surferTable import listOfChemicalNames, listOfCASNames
from compiler import surferTableInput, soil, groundWater, soilVapor
from utility import *

from surferTable.models import Allchemicals

def index(request):
    
    # get drop down list values from specific columns of config table
    listOfChemicalNames = [chemical.encode("utf8") for chemical in Allchemicals.objects.values_list('c3', flat=True)]
    listOfChemicalNames.pop(0) # pop off the column header
    listOfCASNames = [chemical.encode("utf8") for chemical in Allchemicals.objects.values_list('c2', flat=True)]
    listOfCASNames.pop(0) # pop off the column header

    if request.method == 'GET':
        landUse = request.GET.get('LandUse', '')
        groundWaterUtility = request.GET.get('GroundWaterUtility', '')
        distanceToNearest = request.GET.get('DistanceToNearest', '')
        contaminantType = request.GET.get('ContaminantType', '')
        contaminantName = request.GET.get('ContaminantName', '')


        #  only do lookup if values are from the available list
        if (contaminantType == contaminantTypeCas) or (contaminantType == contaminantTypeChemical):
            # convert CAS to chemical name
            if contaminantType == contaminantTypeCas:
                contaminantName = convertCASNameToChemicalName(contaminantName)

            # pass user inputs to compiler
            [soil, groundWater, soilVapor] = surferTableInput(landUse, groundWaterUtility, distanceToNearest, contaminantName)

            #print soil
            #print groundWater
            #print soilVapor
    try:
        soil
    except NameError:
        return render(request, 'index.html', {'listOfChemicalNames': listOfChemicalNames,
                                          'listOfCASNames': listOfCASNames})
    else:
        return render(request, 'index.html', {'listOfChemicalNames': listOfChemicalNames,
                                          'listOfCASNames': listOfCASNames,
                                          'soil': soil,
                                          'groundWater': groundWater,
                                          'soilVapor': soilVapor})
